Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 22
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a22
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o aufgabe22  aufgabe22.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./aufgabe22 <Zeichenkette> <Zeichenkette> <Zeichenkette> <Zeichenkette> 
2. Zeichenkette= das auszugebende Argument

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    pid_t p[3];
    int i;
 printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
printf("Elternprozess: PID = %d, Argument 1: %s\n", getpid(), argv[1]);

    for (i = 0; i < 3; i++) {
        p[i] = fork();

        if (p[i] == 0) {
            printf("Kindprozess %d: PID = %d, Argument %d: %s\n", i+1, getpid(), i+2, argv[i+2]);
            if (i == 2) {
                sleep(1);
                return 2;
            }
		while(1) {}           
        } 
    }

   

    sleep(2);
    kill(p[0], SIGTERM);
    kill(p[1], SIGKILL);
    kill(p[2], SIGKILL);

    for (i = 0; i < 3; i++) {
        int status;
        wait(&status);
        if (WIFEXITED(status)) {
            printf("Kindprozess %d mit PID %d wurde mit Status %d beendet\n", i+1, p[i], WEXITSTATUS(status));
        } else {
            printf("Kindprozess %d mit PID %d wurde unerwartet beendet\n", i+1, p[i]);
        }
    }

    return 0;
}

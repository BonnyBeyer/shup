Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 23
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a23
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o aufgabe23 aufgabe2.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./aufgabe23
2. Senden der Signale SIGINT und SIGTERM
kill -2 <PID> //SIGINT
kill -15 <PID> //SIGTERM
3. PID abrufen 
ps -ef |grep aufgabe23

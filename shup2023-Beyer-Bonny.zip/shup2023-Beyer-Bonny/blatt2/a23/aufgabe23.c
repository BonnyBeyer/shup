#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

// Variable, um die Anzahl der empfangenen Signale zu zählen
int signalReceived = 0;

// Signal-Handler-Funktion für SIGTERM und SIGINT
void signalHandler(int signalNumber) {
    if (signalNumber == SIGTERM) {
        printf("SIGTERM eingetroffen\n");
    } else if (signalNumber == SIGINT) {
        printf("SIGINT eingetroffen\n");
    }
    signalReceived++;
    if (signalReceived >= 3) {
        printf("Beenden des Programmes nach 3 eingetroffenen Signalen.\n");
        exit(5);
    }
}

int main() {
    printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    
    signal(SIGTERM, signalHandler);
    signal(SIGINT, signalHandler);

    printf("Programm gestarted. Warten auf SIGTERM oder  SIGINT Signal.\n");

    while(1) {
        sleep(1);
    }

    return 0;
}

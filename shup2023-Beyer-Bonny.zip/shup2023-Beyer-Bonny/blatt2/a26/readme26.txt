Autor: Bonny Beyer 
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 26
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a26
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o midshellA26 midshellA26.c 
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./midshellA26
2. Beenden des Programmes mit:
schluss

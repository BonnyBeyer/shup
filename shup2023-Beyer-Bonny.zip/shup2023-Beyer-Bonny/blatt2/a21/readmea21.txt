Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 21
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a21
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o aufgabe21 aufgabe21.c 
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./aufgabe21
2. PROGNAME = Name des durch a23 zu startenden Programms

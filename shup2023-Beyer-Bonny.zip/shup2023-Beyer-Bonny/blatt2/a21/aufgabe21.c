#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    pid_t p = fork();

    if (p == 0) {
        // Prozess1
        printf("Prozess1: PID = %d, PPID = %d\n", getpid(), getppid());
    } else {
        // Prozess2
        printf("Prozess2: PID = %d, PPID = %d\n", getpid(), getppid());
    }

    while (1) {
        // Endlosschleife.
    }

 }

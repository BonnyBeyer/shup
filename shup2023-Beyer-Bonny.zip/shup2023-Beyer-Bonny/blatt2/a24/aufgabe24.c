#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>

int main(int argc, char *argv[]) {
printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    pid_t p;
    int status;

    p = fork();

    if (p == 0) {
        if (argc > 1) {
            execvp(argv[1], &argv[1]);
        } else {
            execlp("./alternativ_Programm","", NULL);
        }

        perror("exec");
        exit(1);
    }

    if (waitpid(p, &status, 0) < 0) {
        perror("waitpid");
        exit(1);
    }

    printf("PID des Kindprozesses: %d\n", p);
    printf("Endestatus des Kindprozesses: %d\n", WEXITSTATUS(status));

    return 0;
}

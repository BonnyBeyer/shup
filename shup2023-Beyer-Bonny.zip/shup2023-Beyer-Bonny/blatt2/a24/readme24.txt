Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 24
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a24
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o aufgabe24 aufgabe24.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./aufgabe24 <PROGNAME>
2. PROGNAME = Name des durch a24 zu startenden Programms

#include <stdio.h>

int main() {
    printf("Alternativ Programm ausgeführt\n");
    return 0;
}

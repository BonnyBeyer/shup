#include <stdio.h>

int main() {
    printf("Hallo Welt!\n");
    return 0;
}

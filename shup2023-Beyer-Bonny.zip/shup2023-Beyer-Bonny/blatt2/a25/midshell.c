#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <limits.h>
#include <libgen.h>

#define MAX_EINGABE_GROESSE 256
#define MAX_PFAD_GROESSE 256
#define MAX_PFAD_ELEMENTE 256

int findeAusfuehrbareDatei(char *pfad, const char *befehl) {
    char *verzeichnis, *pfadKopie;

    pfadKopie = strdup(getenv("PATH"));
    verzeichnis = strtok(pfadKopie, ":");

    while (verzeichnis != NULL) {
        snprintf(pfad, MAX_PFAD_GROESSE, "%s/%s", verzeichnis, befehl);

        if (access(pfad, X_OK) == 0) {
            free(pfadKopie);
            return 1;
        }

        verzeichnis = strtok(NULL, ":");
    }

    free(pfadKopie);
    return 0;
}
int main() {
    printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    char eingabe[MAX_EINGABE_GROESSE];
    char *argumente[MAX_PFAD_ELEMENTE];
    char *token;
    int anzahlArgumente;
    pid_t prozessID;
    int status;
    char aktuellesVerzeichnis[MAX_PFAD_GROESSE];
    char pfad[MAX_PFAD_GROESSE];

    while (1) {
        if (getcwd(aktuellesVerzeichnis, sizeof(aktuellesVerzeichnis)) == NULL) {
            perror("getcwd");
            exit(1);
        }
        printf("Midi-Shell in %s\n> ", aktuellesVerzeichnis);

        if (fgets(eingabe, MAX_EINGABE_GROESSE, stdin) == NULL) {
            perror("fgets");
            exit(1);
        }

        eingabe[strlen(eingabe) - 1] = '\0';

        if (strcmp(eingabe, "schluss") == 0) {
            break;
        }

        anzahlArgumente = 0;
        token = strtok(eingabe, " ");
        while (token != NULL) {
            argumente[anzahlArgumente++] = token;
            token = strtok(NULL, " ");
        }
        argumente[anzahlArgumente] = NULL;

        if (strchr(argumente[0], '/') != NULL) {
            strncpy(pfad, argumente[0], MAX_PFAD_GROESSE);
        } else {
            if (!findeAusfuehrbareDatei(pfad, argumente[0])) {
                fprintf(stderr, "Befehl nicht gefunden: %s\n", argumente[0]);
                continue;
            }
        }

        prozessID = fork();
        if (prozessID < 0) {
            perror("fork");
            exit(1);
        }

        if (prozessID == 0) {
            execv(pfad, argumente);
            perror("execv");
            exit(1);
        }

        if (waitpid(prozessID, &status, 0) < 0) {
            perror("waitpid");
            exit(1);
        }
    }
}

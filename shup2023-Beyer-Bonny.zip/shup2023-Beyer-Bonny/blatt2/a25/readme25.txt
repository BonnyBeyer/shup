Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 2: Prozesse unter Linux
Aufgabe 25
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt2/a25
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o midshell midshell.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./midshell
2. Beenden des Programmes mit:
schluss

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <time.h>

#define DRUCKER_ANZAHL 2
#define WARTESCHLANGE_GROESSE 5
#define SIMULATIONSZEIT 60

struct Druckauftrag {
    int auftragId;
    int seitenAnzahl;
};

int warteSemaphore(int sem_id) {
    struct sembuf sem_op = {0, -1, 0};
    return semop(sem_id, &sem_op, 1);
}

int signalSemaphore(int sem_id) {
    struct sembuf sem_op = {0, 1, 0};
    return semop(sem_id, &sem_op, 1);
}

void druckerProzess(int druckerId, int sem_id, struct Druckauftrag *warteschlange) {
    srand(time(NULL) ^ getpid());
    int auftragIndex = 0;
    time_t startZeit = time(NULL);
    while (time(NULL) - startZeit < SIMULATIONSZEIT) {
        warteSemaphore(sem_id);
        if (warteschlange[auftragIndex].auftragId != -1) {
            printf("Drucker %d druckt Auftrag %d (%d Seiten)\n", druckerId, warteschlange[auftragIndex].auftragId, warteschlange[auftragIndex].seitenAnzahl);
            sleep(warteschlange[auftragIndex].seitenAnzahl);

            printf("Drucker %d hat Auftrag %d fertiggestellt\n", druckerId, warteschlange[auftragIndex].auftragId);
            warteschlange[auftragIndex].auftragId = -1;
            auftragIndex = (auftragIndex + 1) % WARTESCHLANGE_GROESSE;
        }
        signalSemaphore(sem_id);
        sleep(1);
    }
}

void anwendungsProzess(int appId, int sem_id, struct Druckauftrag *warteschlange) {
    srand(time(NULL) ^ getpid());
    sleep(rand() % 4); // Wartezeit zwischen 0 und 4 Sekunden (0 bis 4 Minuten)
    struct Druckauftrag neuerAuftrag;
    neuerAuftrag.auftragId = appId;
    neuerAuftrag.seitenAnzahl = (rand() % 5) + 2; // Seitenanzahl zwischen 2 und 6
    int warteschlangeIndex = 0;
    while (1) {
        warteSemaphore(sem_id);
        if (warteschlange[warteschlangeIndex].auftragId == -1) {
            warteschlange[warteschlangeIndex] = neuerAuftrag;
            printf("Anwendung %d hat Druckauftrag %d (%d Seiten) eingereiht\n", appId, neuerAuftrag.auftragId, neuerAuftrag.seitenAnzahl);
            signalSemaphore(sem_id);
            break;
        }
        signalSemaphore(sem_id);
        warteschlangeIndex = (warteschlangeIndex + 1) % WARTESCHLANGE_GROESSE;
        sleep(1);
    }
}

int main() {
    printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    int sem_id = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    semctl(sem_id, 0, SETVAL, 1);

   
int shmId = shmget(IPC_PRIVATE, sizeof(struct Druckauftrag) * WARTESCHLANGE_GROESSE, IPC_CREAT | 0600);
struct Druckauftrag *warteschlange = (struct Druckauftrag *)shmat(shmId, NULL, 0);
for (int i = 0; i < WARTESCHLANGE_GROESSE; i++) {
warteschlange[i].auftragId = -1;
}

pid_t pid;

// Druckerprozesse erstellen
for (int i = 0; i < DRUCKER_ANZAHL; i++) {
pid = fork();
if (pid == 0) {
druckerProzess(i, sem_id, warteschlange);
exit(0);
} else if (pid < 0) {
perror("Fehler beim Erstellen des Druckerprozesses");
exit(1);
}
}

// Anwendungsprozesse erstellen
int anwendungAnzahl = 10;
for (int i = 0; i < anwendungAnzahl; i++) {
pid = fork();
if (pid == 0) {
anwendungsProzess(i, sem_id, warteschlange);
exit(0);
} else if (pid < 0) {
perror("Fehler beim Erstellen des Anwendungsprozesses");
exit(1);
}
}
// Warte auf alle Anwendungsprozesse
for (int i = 0; i < anwendungAnzahl; i++) {
wait(NULL);
}

// Simulationszeit abwarten
sleep(SIMULATIONSZEIT);

// Semaphore und Shared Memory aufräumen
semctl(sem_id, 0, IPC_RMID);
shmdt(warteschlange);
shmctl(shmId, IPC_RMID, NULL);

return 0;
}

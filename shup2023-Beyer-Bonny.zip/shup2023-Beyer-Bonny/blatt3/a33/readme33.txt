Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 3: Synchronisation
Aufgabe 33
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt3/a33
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o druckspooler druckspooler.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./druckspooler
Pseudocode:
Definiere Konstanten: DRUCKER_ANZAHL, WARTESCHLANGE_GROESSE, SIMULATIONSZEIT
Definiere die Struktur "Druckauftrag" mit den Feldern: auftragsId, seitenAnzahl
Funktion warteSemaphore(semId):
- Führe Semaphore-Operation aus, um auf das Signal zu warten

Funktion signalSemaphore(semId):
- Führe Semaphore-Operation aus, um ein Signal zu senden

Funktion druckerProzess(druckerId, semId, Warteschlange):
- Initialisiere den Zufallsgenerator
- Wiederhole solange die aktuelle Zeit kleiner als die Simulationszeit ist:
- Warte auf das Semaphore-Signal
- Wenn ein Druckauftrag in der Warteschlange vorhanden ist:
- Drucke den Auftrag
- Warte eine Zeit, die der Seitenanzahl des Auftrags entspricht
- Markiere den Auftrag als abgeschlossen
- Gehe zum nächsten Auftrag in der Warteschlange
- Sende das Semaphore-Signal
- Warte 1 Sekunde

Funktion anwendungsProzess(anwendungsId, semId, Warteschlange):
- Initialisiere den Zufallsgenerator
- Warte eine zufällige Zeit zwischen 0 und 4 Sekunden
- Erstelle einen neuen Druckauftrag mit zufälliger Seitenanzahl
- Wiederhole solange der Auftrag nicht in der Warteschlange ist:
- Warte auf das Semaphore-Signal
- Wenn ein Platz in der Warteschlange frei ist:
- Füge den Auftrag zur Warteschlange hinzu
- Sende das Semaphore-Signal
- Beende die Schleife
- Ansonsten:
- Sende das Semaphore-Signal
- Gehe zum nächsten Platz in der Warteschlange
- Warte 1 Sekunde

Hauptprogramm:
- Erstelle ein Semaphore und initialisiere es
- Erstelle einen gemeinsamen Speicherbereich für die Warteschlange
- Initialisiere die Warteschlange
- Erstelle Druckerprozesse
- Erstelle Anwendungsprozesse
- Warte auf das Ende aller Anwendungsprozesse
- Warte die Simulationszeit ab
- Räume Semaphore und gemeinsamen Speicherbereich auf
- Beende das Programm

#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

int main(int argc, char *argv[]) {
     printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    if (argc != 3) {
        printf("Benutzerhinweis: %s <Schleifendurchläufe> <ZufälligerSeed>\n", argv[0]);
        exit(1);
    }

    int iterationen = atoi(argv[1]);
    int startwert = atoi(argv[2]);

    // Erstellen des Shared-Memory-Bereichs
    key_t schluessel = ftok(".", 'a');
    int shmId = shmget(schluessel, sizeof(int), IPC_CREAT | 0666);
    int *gemeinsamerSpeicher = (int *)shmat(shmId, NULL, 0);

    srand(startwert); // Zufallsgenerator initialisieren

    pid_t pid = fork();

    if (pid == 0) { // Kindprozess
        for (int i = 0; i < iterationen; i++) {
            printf("Kind liest: %d\n", *gemeinsamerSpeicher);
        }
        shmdt(gemeinsamerSpeicher);
    } else if (pid > 0) { // Vaterprozess
        for (int i = 0; i < iterationen; i++) {
            *gemeinsamerSpeicher = rand();
            printf("Vater schreibt: %d\n", *gemeinsamerSpeicher);
        }
        wait(NULL); // Auf das Ende des Kindprozesses warten
        shmdt(gemeinsamerSpeicher);
        shmctl(shmId, IPC_RMID, NULL); // Shared-Memory-Bereich entfernen
    } else {
        perror("fork");
        exit(1);
    }

    return 0;
}

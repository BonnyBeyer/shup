Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 3:Synchronisation
Aufgabe 32
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt3/a32
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o sharedMemoryA32 sharedMemoryA32.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./sharedMemoryA32 <Schleifendurchläufe><RandomSeed>
Pseudocode:
Wenn die Anzahl der Kommandozeilenargumente nicht 3 ist:
    Gib die Verwendungsnachricht aus und beende das Programm

Lese die Anzahl der Iterationen und den Startwert (Seed) aus den Kommandozeilenargumenten

Erstelle einen Shared-Memory-Bereich der Größe eines Integers

Initialisiere den Zufallsgenerator mit dem Startwert (Seed)

Erzeuge einen Kindprozess

Wenn es sich um den Kindprozess handelt:
    Für jede Iteration:
        Lese den Wert aus dem Shared-Memory und gib ihn aus
    Trenne den Shared-Memory-Bereich vom Kindprozess

Wenn es sich um den Vaterprozess handelt:
    Für jede Iteration:
        Schreibe einen zufälligen Wert in den Shared-Memory und gib ihn aus
    Warte auf das Ende des Kindprozesses
    Trenne den Shared-Memory-Bereich vom Vaterprozess
    Entferne den Shared-Memory-Bereich


Autor: Bonny Beyer
Shell und Prozesse SS 2023
Blatt 3: Synchronisation
Aufgabe 31
Vorbedingung:
Das aktuelle Arbeitsverzeichnis ist:
blatt3/a31
Generieranleitung:
1. Generieren des ausfuehrbaren Programms mit:
gcc -o smaphoreA31 smaphoreA31.c
Bedienungsanleitung:
1. Start des ausfuehrbaren Programms mit:
./smaphore

Pseudocode::

1. Definiere die Funktion warteSemaphore:
    a. Erstelle eine semOp Struktur und setze ihre Werte auf {0, -1, 0}
    b. Führe semop mit semId und der semOp Struktur aus

2. Definiere die Funktion signalSemaphore:
    a. Erstelle eine semOp Struktur und setze ihre Werte auf {0, 1, 0}
    b. Führe semop mit semId und der semOp Struktur aus

3. Beginne das Hauptprogramm:
    a. Erstelle zwei Semaphoren semId1 und semId2 mit IPC_PRIVATE und den Berechtigungen 0600
    b. Setze den Anfangswert von beiden Semaphoren auf 0
    c. Erstelle einen Kindprozess mit fork und speichere den Prozess-Identifikator (PID) in pid

4. Wenn pid gleich 0 ist (im Kindprozess):
    a. Rufe warteSemaphore für semId1 auf
    b. Gib eine Aufforderung zur Benutzereingabe aus und warte auf eine Eingabe
    c. Rufe signalSemaphore für semId2 auf
    d. Gib aus, dass der Kindprozess beendet wurde

5. Wenn pid größer als 0 ist (im Vaterprozess):
    a. Gib eine Aufforderung zur Benutzereingabe aus und warte auf eine Eingabe
    b. Rufe signalSemaphore für semId1 auf
    c. Rufe warteSemaphore für semId2 auf
    d. Gib aus, dass der Vaterprozess beendet wurde
    e. Warte auf das Ende des Kindprozesses mit wait

6. Wenn pid kleiner als 0 ist (Fehler beim Erstellen des Kindprozesses):
    a. Gib eine Fehlermeldung aus
    b. Beende das Programm mit einem Fehlercode

7. Entferne die Semaphoren semId1 und semId2 mit IPC_RMID

8. Beende das Programm 

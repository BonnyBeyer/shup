#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>

void warteSemaphore(int semId) {
    struct sembuf semOp = {0, -1, 0};
    semop(semId, &semOp, 1);
}

void signalSemaphore(int semId) {
    struct sembuf semOp = {0, 1, 0};
    semop(semId, &semOp, 1);
}

int main() {
    printf("Diese Lösung wurde erstellt von Bonny Beyer\n");
    int semId1 = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);
    int semId2 = semget(IPC_PRIVATE, 1, IPC_CREAT | 0600);

    semctl(semId1, 0, SETVAL, 0);
    semctl(semId2, 0, SETVAL, 0);

    pid_t pid = fork();

    if (pid == 0) {
        // Kindprozess
        warteSemaphore(semId1);
        printf("Kindprozess wartet auf Benutzereingabe: ");
        getchar();
        signalSemaphore(semId2);
        printf("Kindprozess beendet.\n");
    } else if (pid > 0) {
        // Vaterprozess
        printf("Vaterprozess wartet auf Benutzereingabe: ");
        getchar();
        signalSemaphore(semId1);
        warteSemaphore(semId2);
        printf("Vaterprozess beendet.\n");
        wait(NULL);
    } else {
        perror("Fehler beim Erstellen des Kindprozesses.");
        exit(EXIT_FAILURE);
    }

    semctl(semId1, 0, IPC_RMID);
    semctl(semId2, 0, IPC_RMID);

    return 0;
}
